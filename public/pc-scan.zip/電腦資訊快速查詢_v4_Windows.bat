@echo off
setlocal
chcp 65001 >nul
rem 實驗室電腦硬體盤點工具 v4.1（Windows）
rem PowerShell 只讀取硬體資訊；上傳改用 Windows 內建的 curl.exe（自動重試、等待時間較長），
rem curl 失敗時才改用 PowerShell 上傳（會套用 Windows 的 proxy 設定）。

set "WEB_APP_URL=https://script.google.com/macros/s/AKfycbwordYLp0W9hmuPfSMkAxrYrR_S10jbSjSPzNTuev6aEGDykQWVC4FvBEHja3M0eDgb/exec"
set "API_TOKEN=OB89GdHTmEdE0JjThsNtZbVWMNsWqV7UguvLXKPC__E"
set "WORK=%TEMP%\minar-pc-inventory"

if not exist "%WORK%" mkdir "%WORK%"
if exist "%WORK%\payload.json" del /q "%WORK%\payload.json"
if exist "%WORK%\response.json" del /q "%WORK%\response.json"

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0pc-inventory-windows.ps1" -WorkDir "%WORK%"
if errorlevel 1 goto fail_collect

echo [7/7] 上傳 Google Sheet...
where curl.exe >nul 2>nul
if errorlevel 1 goto upload_ps

curl.exe -sS -L --ssl-no-revoke --connect-timeout 15 --max-time 90 --retry 3 --retry-delay 5 --retry-connrefused -H "Content-Type: application/json; charset=utf-8" --data-binary "@%WORK%\payload.json" -o "%WORK%\response.json" "%WEB_APP_URL%"
if not errorlevel 1 goto check

:upload_ps
echo       curl 上傳失敗，改用 PowerShell 再試...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0pc-inventory-windows.ps1" -WorkDir "%WORK%" -Upload
if errorlevel 1 goto fail_upload

:check
findstr /c:"\"ok\":true" "%WORK%\response.json" >nul
if errorlevel 1 goto fail_server
echo.
echo ✓ 盤點完成！Google Sheet 回應：
type "%WORK%\response.json"
echo.
goto end

:fail_collect
echo ✗ 讀取硬體資訊失敗，請把上方訊息截圖給系統維護者。
goto end

:fail_upload
echo.
echo ✗ 上傳失敗：連不上 Google（已自動重試多次）。
echo   請用瀏覽器開啟 https://script.google.com 確認這台電腦連得上；
echo   若打不開，可能是網路或防火牆擋住了 Google。
goto end

:fail_server
echo.
echo ✗ Google Sheet 回傳錯誤：
type "%WORK%\response.json"
echo.

:end
echo.
pause
endlocal
