﻿# 實驗室電腦硬體盤點工具 v4.1（Windows）— 由「電腦資訊快速查詢_v4_Windows.bat」呼叫
#
# 分工：這支 PowerShell 只負責讀取硬體資訊、產生要上傳的 JSON；
#       上傳由 bat 用 Windows 內建的 curl.exe 處理（有重試、可設逾時），
#       curl 失敗時 bat 才會加上 -Upload 再呼叫一次，改用 PowerShell 上傳（會套用 Windows 的 proxy 設定）。
# 刻意寫成可直接閱讀的明文腳本：不編碼、不動態執行字串，避免被防毒軟體誤判。
# 上傳網址與 token 由 bat 以環境變數 WEB_APP_URL、API_TOKEN 傳入。

param(
    [Parameter(Mandatory = $true)][string]$WorkDir,
    [switch]$Upload
)

$ErrorActionPreference = "Stop"
$PayloadFile  = Join-Path $WorkDir "payload.json"
$ResponseFile = Join-Path $WorkDir "response.json"
$Utf8NoBom    = New-Object System.Text.UTF8Encoding($false)

function Clean-Text($value) {
    if ($null -eq $value) { return "" }
    return ([string]$value).Trim()
}

function Is-ValidSerial($serial) {
    if ([string]::IsNullOrWhiteSpace($serial)) { return $false }
    $bad = @(
        "To Be Filled By O.E.M.",
        "Default string",
        "System Serial Number",
        "None",
        "Unknown"
    )
    return -not ($bad -contains $serial.Trim())
}

# ---------- 備援上傳：curl 失敗時才會走到這裡 ----------
if ($Upload) {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        [Net.ServicePointManager]::Expect100Continue = $false
        try { [System.Net.WebRequest]::DefaultWebProxy.Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials } catch {}

        $body = [System.IO.File]::ReadAllBytes($PayloadFile)
        $maxTry = 2
        $location = $null
        $content = $null
        for ($try = 1; $try -le $maxTry; $try++) {
            try {
                # 不自動跟隨轉址：Apps Script 會先 302 轉到一次性的結果網址，
                # 結果網址只能用 GET 取，若沿用 POST 會得到雲端硬碟的「找不到網頁」
                $req = [System.Net.HttpWebRequest]::Create($env:WEB_APP_URL)
                $req.Method = "POST"
                $req.ContentType = "application/json; charset=utf-8"
                $req.AllowAutoRedirect = $false
                $req.Timeout = 90000
                $req.ReadWriteTimeout = 90000
                $stream = $req.GetRequestStream()
                $stream.Write($body, 0, $body.Length)
                $stream.Close()
                $resp = $req.GetResponse()
                $location = $resp.Headers["Location"]
                if (-not $location) {
                    $reader = New-Object System.IO.StreamReader($resp.GetResponseStream(), [System.Text.Encoding]::UTF8)
                    $content = $reader.ReadToEnd()
                    $reader.Close()
                }
                $resp.Close()
                break
            } catch {
                if ($try -eq $maxTry) { throw }
                Write-Host ("      仍然失敗：{0}，5 秒後再試一次..." -f $_.Exception.Message) -ForegroundColor Yellow
                Start-Sleep -Seconds 5
            }
        }
        if ($location) {
            # 資料已送達；結果網址只能讀一次，所以這一步不重試
            $wc = New-Object System.Net.WebClient
            $wc.Encoding = [System.Text.Encoding]::UTF8
            $content = $wc.DownloadString($location)
        }
        [System.IO.File]::WriteAllText($ResponseFile, $content, $Utf8NoBom)
        exit 0
    } catch {
        Write-Host ("      PowerShell 上傳也失敗：{0}" -f $_.Exception.Message) -ForegroundColor Red
        exit 1
    }
}

# ---------- 讀取硬體資訊 ----------
try {
    Write-Host ""
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host "    實驗室電腦硬體盤點工具 v4.1（Windows）" -ForegroundColor Cyan
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host ""

    Write-Host "[1/7] 讀取系統資訊..."
    $cs   = Get-CimInstance Win32_ComputerSystem
    $bios = Get-CimInstance Win32_BIOS
    $os   = Get-CimInstance Win32_OperatingSystem

    $pcName       = $env:COMPUTERNAME
    # 主機名稱：網路上看到的名稱（保留大小寫、可超過 15 字），電腦名稱則是 Windows 的 NetBIOS 名稱
    $hostname     = Clean-Text ([System.Net.Dns]::GetHostName())
    $manufacturer = Clean-Text $cs.Manufacturer
    $model        = Clean-Text $cs.Model
    $serial       = Clean-Text $bios.SerialNumber

    if (Is-ValidSerial $serial) {
        $deviceId = $serial
    } else {
        $deviceId = $pcName
    }

    Write-Host "[2/7] 讀取 CPU..."
    $cpu = ((Get-CimInstance Win32_Processor | ForEach-Object {
        Clean-Text $_.Name
    }) | Where-Object { $_ }) -join " + "

    Write-Host "[3/7] 讀取主機板..."
    $board = Get-CimInstance Win32_BaseBoard | Select-Object -First 1
    $boardName = ((Clean-Text $board.Manufacturer) + " " + (Clean-Text $board.Product)).Trim()

    Write-Host "[4/7] 讀取 RAM..."
    $ramModules = @(Get-CimInstance Win32_PhysicalMemory)
    $ramBytes = ($ramModules | Measure-Object -Property Capacity -Sum).Sum
    $ramTotalGB = if ($ramBytes) { [math]::Round($ramBytes / 1GB, 0) } else { 0 }
    $ramCount = $ramModules.Count

    $ramSpeeds = @($ramModules |
        ForEach-Object { $_.ConfiguredClockSpeed } |
        Where-Object { $_ } |
        Sort-Object -Unique)
    $ramSpeed = $ramSpeeds -join " / "

    $ramDetail = ($ramModules | ForEach-Object {
        $m = Clean-Text $_.Manufacturer
        $p = Clean-Text $_.PartNumber
        $c = if ($_.Capacity) { [math]::Round($_.Capacity / 1GB, 0) } else { 0 }
        $s = $_.ConfiguredClockSpeed
        "$m $p ${c}GB ${s}MT/s".Trim()
    }) -join " | "

    Write-Host "[5/7] 讀取 GPU / VRAM..."
    $gpuNames = New-Object System.Collections.Generic.List[string]
    $gpuVrams = New-Object System.Collections.Generic.List[string]

    $nvidiaNames = @()

    if (Get-Command nvidia-smi -ErrorAction SilentlyContinue) {
        try {
            $nvRows = @(nvidia-smi --query-gpu=name,memory.total --format=csv,noheader,nounits 2>$null)
            foreach ($row in $nvRows) {
                if ([string]::IsNullOrWhiteSpace($row)) { continue }
                $parts = $row -split ",", 2
                if ($parts.Count -ge 2) {
                    $name = $parts[0].Trim()
                    [double]$mib = 0
                    [void][double]::TryParse($parts[1].Trim(), [ref]$mib)
                    $gb = if ($mib -gt 0) { [math]::Round($mib / 1024, 1) } else { 0 }
                    $gpuNames.Add($name)
                    $gpuVrams.Add(("{0} GB" -f $gb))
                    $nvidiaNames += $name
                }
            }
        } catch {
            # 若 nvidia-smi 失敗，下面會改用 Windows CIM。
        }
    }

    # 只保留獨立顯卡，排除遠端、虛擬顯示卡與 Intel 內顯。
    $excludeGpuPattern = 'DeskIn|Virtual Display|Remote Display|Microsoft Remote|Microsoft Basic Display|RDP|Citrix|VMware|VirtualBox|Parsec|Splashtop|Intel\(R\).*Graphics|Intel.*UHD|Intel.*HD Graphics|Intel.*Iris'

    $windowsGpus = @(Get-CimInstance Win32_VideoController)
    foreach ($g in $windowsGpus) {
        $name = Clean-Text $g.Name
        if (-not $name) { continue }
        if ($name -match $excludeGpuPattern) { continue }
        if ($name -match "NVIDIA" -and $nvidiaNames.Count -gt 0) { continue }
        if ($name -match '^AMD Radeon\(TM\) Graphics$|^AMD Radeon Graphics$') { continue }

        $gpuNames.Add($name)

        if ($g.AdapterRAM -and [double]$g.AdapterRAM -gt 0) {
            $gb = [math]::Round(([double]$g.AdapterRAM) / 1GB, 1)
            $gpuVrams.Add(("{0} GB (Windows 回報)" -f $gb))
        } else {
            $gpuVrams.Add("未知")
        }
    }

    $uniqueGpuNames = @($gpuNames | Select-Object -Unique)

    if ($uniqueGpuNames.Count -eq 0) {
        $gpuName = "無獨立顯卡"
        $gpuVram = "-"
    } else {
        $gpuName = $uniqueGpuNames -join " + "
        $gpuVram = $gpuVrams -join " + "
    }

    Write-Host "[6/7] 讀取磁碟..."
    $diskRows = @(Get-CimInstance Win32_DiskDrive |
        Where-Object {
            $_.Size -gt 0 -and $_.InterfaceType -ne "USB"
        })

    $diskInfo = ($diskRows | ForEach-Object {
        $dModel = Clean-Text $_.Model
        $dSize  = [math]::Round(([double]$_.Size) / 1GB, 0)
        "$dModel ${dSize}GB"
    }) -join " | "

    $osName    = Clean-Text $os.Caption
    $osVersion = Clean-Text $os.Version
    $osBuild   = Clean-Text $os.BuildNumber

    Write-Host "[網路] 讀取網卡、IP 與 MAC..."

    # 只看實體網卡（排除 VMware、Hyper-V、VPN 等虛擬網卡與藍牙），優先取已連線的
    $adapters = @()
    try {
        $physical = @(Get-NetAdapter -Physical -ErrorAction Stop |
            Where-Object { $_.InterfaceDescription -notmatch 'Bluetooth' })
        $adapters = @($physical | Where-Object { $_.Status -eq 'Up' })
        if ($adapters.Count -eq 0) { $adapters = $physical }
        $adapters = @($adapters | Sort-Object ifIndex)
    } catch {
        $adapters = @()
    }

    $macAddress = ($adapters | ForEach-Object {
        "{0} {1}" -f $_.Name, (($_.MacAddress -replace '-', ':').ToUpper())
    }) -join " / "

    $localIPv4 = ""
    try {
        $ipSource = if ($adapters.Count -gt 0) {
            @(Get-NetIPAddress -AddressFamily IPv4 -InterfaceIndex $adapters.ifIndex -ErrorAction Stop)
        } else {
            @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop)
        }
        $localIPv4 = @($ipSource |
            Where-Object {
                $_.IPAddress -ne "127.0.0.1" -and
                $_.IPAddress -notlike "169.254.*" -and
                $_.AddressState -eq "Preferred"
            } |
            Select-Object -ExpandProperty IPAddress -Unique) -join " / "
    } catch {
        $localIPv4 = ""
    }

    # 公網 IP 只是參考資訊：用 curl 查，最多等 8 秒，查不到就略過
    $publicIP = "無法取得"
    $ipLocation = "無法取得"
    try {
        $raw = & curl.exe -s --ssl-no-revoke --connect-timeout 5 --max-time 8 "https://ipwho.is/" 2>$null
        if ($LASTEXITCODE -eq 0 -and $raw) {
            $ipInfo = ($raw -join "") | ConvertFrom-Json
            if ($ipInfo.success -ne $false -and $ipInfo.ip) {
                $publicIP = Clean-Text $ipInfo.ip
                $locationParts = @((Clean-Text $ipInfo.city), (Clean-Text $ipInfo.region), (Clean-Text $ipInfo.country)) | Where-Object { $_ }
                $ipLocation = $locationParts -join ", "
            }
        }
    } catch {}

    $payload = [ordered]@{
        token          = $env:API_TOKEN
        timestamp      = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        deviceId       = $deviceId
        pcName         = $pcName
        hostname       = $hostname
        localIPv4      = $localIPv4
        macAddress     = $macAddress
        publicIP       = $publicIP
        ipLocation     = $ipLocation
        manufacturer   = $manufacturer
        model          = $model
        serial         = $serial
        cpu            = $cpu
        gpu            = $gpuName
        vram           = $gpuVram
        motherboard    = $boardName
        ramTotalGB     = $ramTotalGB
        ramCount       = $ramCount
        ramSpeed       = $ramSpeed
        ramDetail      = $ramDetail
        disks          = $diskInfo
        os             = $osName
        osVersion      = $osVersion
        osBuild        = $osBuild
    }

    # 不能有 BOM，否則 Apps Script 解析 JSON 會失敗
    [System.IO.File]::WriteAllText($PayloadFile, ($payload | ConvertTo-Json -Depth 5 -Compress), $Utf8NoBom)

    Write-Host ""
    Write-Host ("設備識別碼：{0}" -f $deviceId)
    Write-Host ("電腦名稱：  {0}" -f $pcName)
    Write-Host ("主機名稱：  {0}" -f $hostname)
    Write-Host ("內網 IP：   {0}" -f $localIPv4)
    Write-Host ("網卡 MAC：  {0}" -f $macAddress)
    Write-Host ("公網 IP：   {0}" -f $publicIP)
    Write-Host ("IP 位置：   {0}" -f $ipLocation)
    Write-Host ("CPU：       {0}" -f $cpu)
    Write-Host ("GPU：       {0}" -f $gpuName)
    Write-Host ("VRAM：      {0}" -f $gpuVram)
    Write-Host ("RAM：       {0} GB / {1} 條 / {2} MT/s" -f $ramTotalGB, $ramCount, $ramSpeed)
    Write-Host ("磁碟：      {0}" -f $diskInfo)
    Write-Host ""
    exit 0
}
catch {
    Write-Host ""
    Write-Host "✗ 讀取硬體資訊失敗" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    exit 1
}
