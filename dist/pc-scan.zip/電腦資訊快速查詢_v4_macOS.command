#!/usr/bin/env bash
# 實驗室電腦硬體盤點工具 v4（macOS）
# 執行：打開「終端機」，輸入 bash 加一個空格，把本檔拖進視窗後按 Enter
# 試跑（只顯示要送出的資料，不上傳）：DRY_RUN=1 bash 電腦資訊快速查詢_v4_macOS.command

WEB_APP_URL="https://script.google.com/macros/s/AKfycbwordYLp0W9hmuPfSMkAxrYrR_S10jbSjSPzNTuev6aEGDykQWVC4FvBEHja3M0eDgb/exec"
API_TOKEN="OB89GdHTmEdE0JjThsNtZbVWMNsWqV7UguvLXKPC__E"

export LC_ALL=C

trim() { sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//'; }
# JSON 字串跳脫：反斜線、雙引號、控制字元
json_str() { printf '"%s"' "$(printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' | tr '\t\r\n' '   ')"; }
join_by() { local sep="$1"; shift; local out="" x; for x in "$@"; do [ -n "$x" ] || continue; out="${out:+$out$sep}$x"; done; printf '%s' "$out"; }
finish() { echo ""; read -r -p "按 Enter 關閉視窗..." _; exit "$1"; }

echo ""
echo "============================================"
echo "      實驗室電腦硬體盤點工具 v4（macOS）"
echo "============================================"
echo ""

echo "[1/7] 讀取系統資訊..."
hw="$(system_profiler SPHardwareDataType 2>/dev/null)"
hw_field() { printf '%s\n' "$hw" | sed -n "s/^[[:space:]]*$1:[[:space:]]*//p" | head -n1; }

pcName="$(scutil --get ComputerName 2>/dev/null | trim)"
hostname_="$(scutil --get LocalHostName 2>/dev/null | trim)"
[ -n "$hostname_" ] || hostname_="$(hostname | trim)"
[ -n "$pcName" ] || pcName="$hostname_"
manufacturer="Apple"
model="$(join_by ' ' "$(hw_field 'Model Name')" "$(hw_field 'Model Identifier' | sed 's/.*/(&)/')")"
serial="$(hw_field 'Serial Number (system)')"
deviceId="${serial:-$pcName}"

echo "[2/7] 讀取 CPU..."
cpu="$(sysctl -n machdep.cpu.brand_string 2>/dev/null | trim)"
[ -n "$cpu" ] || cpu="$(join_by ' ' "$(hw_field 'Chip')" "$(hw_field 'Processor Name')")"

echo "[3/7] 讀取主機板..."
motherboard=""   # Mac 沒有可讀的主機板型號

echo "[4/7] 讀取 RAM..."
ramTotalGB=$(( $(sysctl -n hw.memsize 2>/dev/null || echo 0) / 1073741824 ))
mem="$(system_profiler SPMemoryDataType 2>/dev/null)"
# Intel Mac 會列出每個插槽（BANK…），Apple 晶片則是焊在晶片上的統一記憶體
mem_rows="$(printf '%s\n' "$mem" | awk -F': ' '
  /BANK|DIMM/ && /:$/ { if (size) print size "|" speed "|" type "|" maker "|" part; size=""; speed=""; type=""; maker=""; part=""; next }
  /^[[:space:]]*Size:/ { if ($2 ~ /GB/) size=$2+0 }
  /^[[:space:]]*Speed:/ { if ($2 ~ /[0-9]/) speed=$2+0 }
  /^[[:space:]]*Type:/ { type=$2 }
  /^[[:space:]]*Manufacturer:/ { maker=$2 }
  /^[[:space:]]*Part Number:/ { part=$2 }
  END { if (size) print size "|" speed "|" type "|" maker "|" part }')"
ramCount=0; speeds=(); details=()
if [ -n "$mem_rows" ]; then
  while IFS='|' read -r size speed type maker part; do
    ramCount=$((ramCount + 1))
    [ -n "$speed" ] && speeds+=("$speed")
    details+=("$(join_by ' ' "$maker" "$part" "$type" "${size}GB" "${speed:+${speed}MT/s}")")
  done <<< "$mem_rows"
else
  ramCount=1
  memType="$(printf '%s\n' "$mem" | sed -n 's/^[[:space:]]*Type:[[:space:]]*//p' | head -n1)"
  memMaker="$(printf '%s\n' "$mem" | sed -n 's/^[[:space:]]*Manufacturer:[[:space:]]*//p' | head -n1)"
  details+=("$(join_by ' ' "$memMaker" "$memType" "${ramTotalGB}GB" "（統一記憶體）")")
fi
ramSpeed="$(printf '%s\n' "${speeds[@]}" | grep . | sort -nu | paste -sd'/' - | sed 's#/# / #g')"
ramDetail="$(join_by ' | ' "${details[@]}")"

echo "[5/7] 讀取 GPU / VRAM..."
gpuNames=(); gpuVrams=()
while IFS='|' read -r name vram cores; do
  [ -n "$name" ] || continue
  # 與 Windows 版一致：排除 Intel 內顯；Apple 晶片的 GPU 是唯一顯示晶片，保留
  case "$name" in *Intel*) continue ;; esac
  gpuNames+=("$(join_by ' ' "$name" "${cores:+(${cores} 核心)}")")
  gpuVrams+=("${vram:-共用記憶體}")
done < <(system_profiler SPDisplaysDataType 2>/dev/null | awk -F': ' '
  /Chipset Model:/ { if (name) print name "|" vram "|" cores; name=$2; vram=""; cores="" }
  /VRAM \((Total|Dynamic, Max)\):/ { vram=$2 }
  /Total Number of Cores:/ { cores=$2 }
  END { if (name) print name "|" vram "|" cores }')
if [ "${#gpuNames[@]}" -eq 0 ]; then
  gpu="無獨立顯卡"; vram="-"
else
  gpu="$(join_by ' + ' "${gpuNames[@]}")"; vram="$(join_by ' + ' "${gpuVrams[@]}")"
fi

echo "[6/7] 讀取磁碟..."
disks=()
for dev in $(diskutil list physical 2>/dev/null | awk '/^\/dev\/disk[0-9]+ \(internal/ { print $1 }'); do
  info="$(diskutil info "$dev" 2>/dev/null)"
  name="$(printf '%s\n' "$info" | sed -n 's/^[[:space:]]*Device \/ Media Name:[[:space:]]*//p' | head -n1)"
  bytes="$(printf '%s\n' "$info" | sed -n 's/^[[:space:]]*Disk Size:.*(\([0-9]*\) Bytes).*/\1/p' | head -n1)"
  [ -n "$bytes" ] || continue
  disks+=("$(join_by ' ' "$name" "$(( bytes / 1073741824 ))GB")")
done
diskInfo="$(join_by ' | ' "${disks[@]}")"

osName="$(sw_vers -productName 2>/dev/null)"
osVersion="$(sw_vers -productVersion 2>/dev/null)"
osBuild="$(sw_vers -buildVersion 2>/dev/null)"

echo "[網路] 讀取網卡、IP 與 MAC..."
# 列出所有實體網路埠（Wi-Fi、乙太網路…），排除沒有 MAC 的橋接埠；有 IP 的才算已連線
macs=(); ips=(); fallbackMacs=()
while IFS='|' read -r port dev mac; do
  case "$mac" in ""|N/A) continue ;; esac
  mac="$(printf '%s' "$mac" | tr 'a-f' 'A-F')"
  fallbackMacs+=("$port $mac")
  ip="$(ipconfig getifaddr "$dev" 2>/dev/null)"
  if [ -n "$ip" ]; then
    macs+=("$port $mac"); ips+=("$ip")
  fi
done < <(networksetup -listallhardwareports 2>/dev/null | awk -F': ' '
  /^Hardware Port:/ { port=$2 }
  /^Device:/ { dev=$2 }
  /^Ethernet Address:/ { print port "|" dev "|" $2 }')
[ "${#macs[@]}" -gt 0 ] || macs=("${fallbackMacs[@]}")
macAddress="$(join_by ' / ' "${macs[@]}")"
localIPv4="$(join_by ' / ' "${ips[@]}")"

publicIP=""; ipLocation=""
ipinfo="$(curl -s --max-time 8 https://ipwho.is/ 2>/dev/null)"
if [ -n "$ipinfo" ] && ! printf '%s' "$ipinfo" | grep -q '"success":false'; then
  field() { printf '%s' "$ipinfo" | sed -n "s/.*\"$1\":\"\([^\"]*\)\".*/\1/p"; }
  publicIP="$(field ip)"
  ipLocation="$(join_by ', ' "$(field city)" "$(field region)" "$(field country)")"
else
  publicIP="無法取得"; ipLocation="無法取得"
fi

timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
json="{\"token\":$(json_str "$API_TOKEN"),\"timestamp\":$(json_str "$timestamp"),\"deviceId\":$(json_str "$deviceId"),\
\"pcName\":$(json_str "$pcName"),\"hostname\":$(json_str "$hostname_"),\"localIPv4\":$(json_str "$localIPv4"),\
\"macAddress\":$(json_str "$macAddress"),\"publicIP\":$(json_str "$publicIP"),\"ipLocation\":$(json_str "$ipLocation"),\
\"manufacturer\":$(json_str "$manufacturer"),\"model\":$(json_str "$model"),\"serial\":$(json_str "$serial"),\
\"cpu\":$(json_str "$cpu"),\"gpu\":$(json_str "$gpu"),\"vram\":$(json_str "$vram"),\"motherboard\":$(json_str "$motherboard"),\
\"ramTotalGB\":${ramTotalGB:-0},\"ramCount\":${ramCount:-0},\"ramSpeed\":$(json_str "$ramSpeed"),\"ramDetail\":$(json_str "$ramDetail"),\
\"disks\":$(json_str "$diskInfo"),\"os\":$(json_str "$osName"),\"osVersion\":$(json_str "$osVersion"),\"osBuild\":$(json_str "$osBuild")}"

if [ -n "${DRY_RUN:-}" ]; then
  echo ""
  echo "（試跑模式，未上傳）要送出的資料："
  printf '%s\n' "$json"
  exit 0
fi

echo "[7/7] 上傳 Google Sheet..."
# 不要加 -X POST：Apps Script 會轉址，curl 需在轉址後改用 GET 取回結果
response="$(printf '%s' "$json" | curl -sL --max-time 30 -H 'Content-Type: application/json; charset=utf-8' --data-binary @- "$WEB_APP_URL")"

if ! printf '%s' "$response" | grep -q '"ok":true'; then
  echo ""
  echo "✗ 盤點失敗"
  echo "Google Sheet 回傳：$response"
  finish 1
fi

action="$(printf '%s' "$response" | sed -n 's/.*"action":"\([^"]*\)".*/\1/p')"
echo ""
echo "✓ 盤點完成！"
echo ""
echo "設備識別碼：$deviceId"
echo "電腦名稱：  $pcName"
echo "主機名稱：  $hostname_"
echo "內網 IP：   $localIPv4"
echo "網卡 MAC：  $macAddress"
echo "公網 IP：   $publicIP"
echo "IP 位置：   $ipLocation"
echo "CPU：       $cpu"
echo "GPU：       $gpu"
echo "VRAM：      $vram"
echo "RAM：       ${ramTotalGB} GB / ${ramCount} 條 / ${ramSpeed} MT/s"
echo "磁碟：      $diskInfo"
echo ""
echo "Google Sheet：$action"
finish 0
