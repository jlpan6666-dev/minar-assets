#!/usr/bin/env bash
# 實驗室電腦硬體盤點工具 v4（Ubuntu / Linux）
# 執行：在終端機輸入  bash 電腦資訊快速查詢_v4_Ubuntu.sh
# 試跑（只顯示要送出的資料，不上傳）：DRY_RUN=1 bash 電腦資訊快速查詢_v4_Ubuntu.sh

WEB_APP_URL="https://script.google.com/macros/s/AKfycbwordYLp0W9hmuPfSMkAxrYrR_S10jbSjSPzNTuev6aEGDykQWVC4FvBEHja3M0eDgb/exec"
API_TOKEN="OB89GdHTmEdE0JjThsNtZbVWMNsWqV7UguvLXKPC__E"

# BIOS 序號、記憶體條資訊需要 root 才讀得到；用 sudo 重新執行自己
if [ "$(id -u)" -ne 0 ]; then
  echo "需要管理員權限讀取 BIOS 序號與記憶體資訊，請輸入密碼："
  # 用 env 傳變數：sudo 預設不允許直接在指令前設定環境變數
  exec sudo env DRY_RUN="${DRY_RUN:-}" bash "$0" "$@"
fi

export LC_ALL=C

trim() { sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//'; }
read_dmi() { cat "/sys/class/dmi/id/$1" 2>/dev/null | trim; }
# JSON 字串跳脫：反斜線、雙引號、控制字元
json_str() { printf '"%s"' "$(printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' | tr '\t\r\n' '   ')"; }
join_by() { local sep="$1"; shift; local out="" x; for x in "$@"; do [ -n "$x" ] || continue; out="${out:+$out$sep}$x"; done; printf '%s' "$out"; }

if ! command -v curl >/dev/null 2>&1; then
  echo "✗ 找不到 curl，請先執行：sudo apt install -y curl"
  exit 1
fi

echo ""
echo "============================================"
echo "     實驗室電腦硬體盤點工具 v4（Ubuntu）"
echo "============================================"
echo ""

echo "[1/7] 讀取系統資訊..."
hostname_="$(hostname | trim)"
pcName="$(hostnamectl --pretty 2>/dev/null | trim)"
[ -n "$pcName" ] || pcName="$hostname_"
manufacturer="$(read_dmi sys_vendor)"
model="$(join_by ' ' "$(read_dmi product_name)" "$(read_dmi product_version)")"
serial="$(read_dmi product_serial)"

case "$serial" in
  ""|"To Be Filled By O.E.M."|"Default string"|"System Serial Number"|"None"|"Unknown"|"0") deviceId="$pcName" ;;
  *) deviceId="$serial" ;;
esac

echo "[2/7] 讀取 CPU..."
cpu="$(grep '^model name' /proc/cpuinfo | cut -d: -f2- | trim | sort -u | paste -sd'+' | sed 's/+/ + /g')"
[ -n "$cpu" ] || cpu="$(lscpu 2>/dev/null | sed -n 's/^Model name:[[:space:]]*//p' | head -n1)"

echo "[3/7] 讀取主機板..."
motherboard="$(join_by ' ' "$(read_dmi board_vendor)" "$(read_dmi board_name)")"

echo "[4/7] 讀取 RAM..."
ramTotalGB=0; ramCount=0; ramSpeed=""; ramDetail=""
if command -v dmidecode >/dev/null 2>&1; then
  # 每條記憶體輸出一行：大小(MB)|速度|廠牌|型號
  mem_rows="$(dmidecode -t 17 2>/dev/null | awk -F': ' '
    /^Memory Device/ { if (size) print size "|" speed "|" maker "|" part; size=""; speed=""; maker=""; part="" }
    /^\tSize:/ { if ($2 ~ /GB/) size=$2*1024; else if ($2 ~ /MB/) size=$2+0; else size="" }
    /^\tConfigured (Memory|Clock) Speed:/ { if ($2 ~ /[0-9]/) speed=$2+0 }
    /^\tManufacturer:/ { maker=$2 }
    /^\tPart Number:/ { part=$2 }
    END { if (size) print size "|" speed "|" maker "|" part }')"
  if [ -n "$mem_rows" ]; then
    totalMB=0; details=(); speeds=()
    while IFS='|' read -r size speed maker part; do
      totalMB=$((totalMB + size)); ramCount=$((ramCount + 1))
      [ -n "$speed" ] && speeds+=("$speed")
      details+=("$(join_by ' ' "$(printf '%s' "$maker" | trim)" "$(printf '%s' "$part" | trim)" "$((size / 1024))GB" "${speed:+${speed}MT/s}")")
    done <<< "$mem_rows"
    ramTotalGB=$(( (totalMB + 512) / 1024 ))
    ramSpeed="$(printf '%s\n' "${speeds[@]}" | sort -nu | paste -sd'/' | sed 's#/# / #g')"
    ramDetail="$(join_by ' | ' "${details[@]}")"
  fi
fi
if [ "$ramTotalGB" -eq 0 ]; then
  ramTotalGB=$(awk '/^MemTotal:/ { printf "%d", $2 / 1048576 + 0.5 }' /proc/meminfo)
fi

echo "[5/7] 讀取 GPU / VRAM..."
gpuNames=(); gpuVrams=()
if command -v nvidia-smi >/dev/null 2>&1; then
  while IFS=',' read -r name mib; do
    name="$(printf '%s' "$name" | trim)"; mib="$(printf '%s' "$mib" | trim)"
    [ -n "$name" ] || continue
    gpuNames+=("$name")
    gpuVrams+=("$(awk -v m="$mib" 'BEGIN { printf "%.1f GB", m / 1024 }')")
  done < <(nvidia-smi --query-gpu=name,memory.total --format=csv,noheader,nounits 2>/dev/null)
fi
if [ "${#gpuNames[@]}" -eq 0 ] && command -v lspci >/dev/null 2>&1; then
  # 只保留獨立顯卡：排除 Intel 內顯與虛擬機顯示卡
  while IFS= read -r line; do
    gpuNames+=("$line"); gpuVrams+=("未知")
  done < <(lspci 2>/dev/null | grep -Ei 'vga|3d controller|display controller' | cut -d: -f3- | trim \
           | grep -Eiv 'intel|vmware|virtualbox|qxl|cirrus|red hat|bochs|virtio|matrox|aspeed')
fi
if [ "${#gpuNames[@]}" -eq 0 ]; then
  gpu="無獨立顯卡"; vram="-"
else
  gpu="$(join_by ' + ' "${gpuNames[@]}")"; vram="$(join_by ' + ' "${gpuVrams[@]}")"
fi

echo "[6/7] 讀取磁碟..."
disks=()
while IFS= read -r line; do
  MODEL=""; SIZE=0; TRAN=""; TYPE=""
  eval "$line"
  [ "$TYPE" = "disk" ] || continue
  [ "$TRAN" = "usb" ] && continue
  [ "${SIZE:-0}" -gt 0 ] 2>/dev/null || continue
  disks+=("$(join_by ' ' "$(printf '%s' "$MODEL" | trim)" "$(( SIZE / 1073741824 ))GB")")
done < <(lsblk -d -n -b -P -o MODEL,SIZE,TRAN,TYPE 2>/dev/null)
diskInfo="$(join_by ' | ' "${disks[@]}")"

osName="$(. /etc/os-release 2>/dev/null; printf '%s' "${PRETTY_NAME:-Linux}")"
osVersion="$(. /etc/os-release 2>/dev/null; printf '%s' "${VERSION_ID:-}")"
osBuild="$(uname -r)"

echo "[網路] 讀取網卡、IP 與 MAC..."
# 只看實體網卡（/sys/class/net/<名稱>/device 存在者），排除 docker、VPN、橋接等虛擬網卡
macs=(); ips=(); fallbackMacs=()
for path in /sys/class/net/*; do
  ifname="$(basename "$path")"
  [ -e "$path/device" ] || continue
  mac="$(tr 'a-f' 'A-F' < "$path/address" 2>/dev/null)"
  [ -n "$mac" ] && [ "$mac" != "00:00:00:00:00:00" ] || continue
  fallbackMacs+=("$ifname $mac")
  ifips="$(ip -4 -o addr show dev "$ifname" 2>/dev/null | awk '{ split($4, a, "/"); print a[1] }' | grep -v '^169\.254\.' | paste -sd' ')"
  if [ -n "$ifips" ]; then
    macs+=("$ifname $mac")
    for x in $ifips; do ips+=("$x"); done
  fi
done
[ "${#macs[@]}" -gt 0 ] || macs=("${fallbackMacs[@]}")
macAddress="$(join_by ' / ' "${macs[@]}")"
localIPv4="$(join_by ' / ' "${ips[@]}")"

publicIP=""; ipLocation=""
ipinfo="$(curl -s --max-time 8 https://ipwho.is/ 2>/dev/null)"
if [ -n "$ipinfo" ] && ! printf '%s' "$ipinfo" | grep -q '"success":false'; then
  field() { printf '%s' "$ipinfo" | sed -n "s/.*\"$1\":\"\([^\"]*\)\".*/\1/p"; }
  publicIP="$(field ip)"
  ipLocation="$(join_by ', ' "$(field city)" "$(field region)" "$(field country)")"
else
  publicIP="無法取得"; ipLocation="無法取得"
fi

timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
json="{\"token\":$(json_str "$API_TOKEN"),\"timestamp\":$(json_str "$timestamp"),\"deviceId\":$(json_str "$deviceId"),\
\"pcName\":$(json_str "$pcName"),\"hostname\":$(json_str "$hostname_"),\"localIPv4\":$(json_str "$localIPv4"),\
\"macAddress\":$(json_str "$macAddress"),\"publicIP\":$(json_str "$publicIP"),\"ipLocation\":$(json_str "$ipLocation"),\
\"manufacturer\":$(json_str "$manufacturer"),\"model\":$(json_str "$model"),\"serial\":$(json_str "$serial"),\
\"cpu\":$(json_str "$cpu"),\"gpu\":$(json_str "$gpu"),\"vram\":$(json_str "$vram"),\"motherboard\":$(json_str "$motherboard"),\
\"ramTotalGB\":${ramTotalGB:-0},\"ramCount\":${ramCount:-0},\"ramSpeed\":$(json_str "$ramSpeed"),\"ramDetail\":$(json_str "$ramDetail"),\
\"disks\":$(json_str "$diskInfo"),\"os\":$(json_str "$osName"),\"osVersion\":$(json_str "$osVersion"),\"osBuild\":$(json_str "$osBuild")}"

if [ -n "${DRY_RUN:-}" ]; then
  echo ""
  echo "（試跑模式，未上傳）要送出的資料："
  printf '%s\n' "$json"
  exit 0
fi

echo "[7/7] 上傳 Google Sheet..."
# 不要加 -X POST：Apps Script 會轉址，curl 需在轉址後改用 GET 取回結果
response="$(printf '%s' "$json" | curl -sL --max-time 30 -H 'Content-Type: application/json; charset=utf-8' --data-binary @- "$WEB_APP_URL")"

if ! printf '%s' "$response" | grep -q '"ok":true'; then
  echo ""
  echo "✗ 盤點失敗"
  echo "Google Sheet 回傳：$response"
  exit 1
fi

action="$(printf '%s' "$response" | sed -n 's/.*"action":"\([^"]*\)".*/\1/p')"
echo ""
echo "✓ 盤點完成！"
echo ""
echo "設備識別碼：$deviceId"
echo "電腦名稱：  $pcName"
echo "主機名稱：  $hostname_"
echo "內網 IP：   $localIPv4"
echo "網卡 MAC：  $macAddress"
echo "公網 IP：   $publicIP"
echo "IP 位置：   $ipLocation"
echo "CPU：       $cpu"
echo "GPU：       $gpu"
echo "VRAM：      $vram"
echo "RAM：       ${ramTotalGB} GB / ${ramCount} 條 / ${ramSpeed} MT/s"
echo "磁碟：      $diskInfo"
echo ""
echo "Google Sheet：$action"
echo ""
